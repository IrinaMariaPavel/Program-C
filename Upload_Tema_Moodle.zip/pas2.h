#include "structuri.h"
#include "pas1.h"

void insert(arbore **arb,nod *p);
void selectie(coada *q, arbore **BTS_l, arbore **BTS_ca);
void postorder(arbore *root,FILE *f);
void deleteARB(arbore *arb);
