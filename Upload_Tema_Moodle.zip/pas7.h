#include"structuri.h"

traseu* cirireDrum(FILE *f,int start[]);
void Drum(traseu *tr, FILE *f, int nodStart,int *ind);
void printGraph(traseu *g,FILE *f);
void DFS(traseu *tr, int curent, int *vizitat, int *drum, int lungime, FILE *f,int *ind);
void freeTraseu(traseu *tr);