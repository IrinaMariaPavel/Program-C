#include"pas3.h"

arbore * minim(arbore* arb) //returneaza minimul ce se afla in dreapta in heap
{   
    if (arb == NULL) return NULL; 
    while (arb->left != NULL) 
    arb = arb->left; 
    return arb; 
}
arbore* elimina(arbore *arb,candidat c)//stergerea candidatului contestat pastrand proprietatile arborelui
{
    //comparam experienta pana gasim candidatul potrivit
    if (arb == NULL) return arb;        
       if (c.experienta < arb->val.experienta) 
         arb->left = elimina(arb->left, c); 
       else if (c.experienta > arb->val.experienta) 
         arb->right = elimina(arb->right, c);
    else {    
        if (arb->left == NULL) {     //daca nu avem nod in stanga il inlocuim cu cel din dreapta       
             arbore *t = arb;            
               arb=arb->right;            
               free(t);      
               return arb;         
            } 
        else if (arb->right == NULL){   //daca nu avem nod in dreapta il inlocuim cu cel din stanga              
             arbore *t = arb;             
             arb=arb->left;             
             free(t);             
             return arb;        
            } 
        //altfel gasim minimul sa inlocuim nodul
        arbore* t = minim(arb->right); 
        arb->val = t->val;  
        arb->right = elimina(arb->right, t->val); 
        free(t);
    } return arb; 
}
void citesteContestatii(arbore *arb)
{
    FILE* f = fopen("Pas_3/contestatii.csv", "r");
    if (f == NULL) {
        printf("Eroare!\n");
        return ;
    }
    char l[265];
    fgets(l, sizeof(l), f);
    while (fgets(l, sizeof(l), f))//citeste contestatiile linie cu linie
    {
    //salveaza contestatia in variabile candidat la fel ca in pas1 si o elimina
    candidat candidat;
    char p[11];
    int i=0;
    while(l[i]!=' ')
    {
        p[i] = toupper(l[i]);
        i++;

    }
    p[i]='\0';
    candidat.statut=returnStatut(p);
    int j=0,ok=0;
    i++;
    
    while(l[i]!=';')
    {
        if(l[i]==' ')
        {candidat.nume[j]='-'; ok=0;}
    else if(ok==0)
    {
        candidat.nume[j]=toupper(l[i]);
        ok=1;
    }else
        candidat.nume[j]=tolower(l[i]);
    i++;
    j++;
    }
    candidat.nume[j]='\0';
    
    i++; j=0;
    while(l[i]!=';')
    {
        p[j]=l[i];
        j++; i++;
    }
    p[j]='\0';
    candidat.experienta=atof(p);
    i++; j=0;
    while(l[i])
    {
        p[j]=l[i];
        j++; i++;
    }
    p[j]='\0';
    candidat.varsta=atoi(p);
    arb=elimina(arb,candidat);
    }
    fclose(f);
}