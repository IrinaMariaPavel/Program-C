#include"pas2.h"

void insert(arbore **arb,nod *p)//insereaza participatul in arbore
{
    if (*arb == NULL)//copiere date
    {
        *arb=(arbore*)malloc(sizeof(arbore));
        strcpy((*arb)->val.nume,p->val.nume);
        (*arb)->val.varsta=p->val.varsta;
        (*arb)->val.experienta=p->val.experienta;
        (*arb)->val.statut=p->val.statut;
        (*arb)->left=NULL;
        (*arb)->right=NULL;
        return;
    }
    //pastrare proprietate arbore
    if (p->val.experienta < (*arb)->val.experienta)
       insert(&(*arb)->left, p);
    else if (p->val.experienta >= (*arb)->val.experienta)
       insert(&(*arb)->right, p);
}
void selectie(coada *q, arbore **BTS_l, arbore **BTS_ca)//imparte elemante din coada in cei doi arbori
{
    nod *p=(nod*)malloc(sizeof(nod));
    p=q->front;
    while(p!=NULL)
    {
        if(strcmp(schimba(p->val.statut),"LORD")==0)
        insert(BTS_l,p);
    else
    insert(BTS_ca,p);
        p=p->next;
    }
    free(p);
}
void postorder(arbore *root,FILE *f)//parcurgere SDR
{
    if (root){
        postorder(root->left,f);
        postorder(root->right,f);
        fprintf(f,"%s %.2f %d %s\n",
            root->val.nume,
            root->val.experienta,
            root->val.varsta,
            schimba(root->val.statut)
         );
    }
    
}
void deleteARB(arbore *arb) //eliberarea memoriei
{
    if (arb == NULL) return;
    deleteARB(arb->left);
    deleteARB(arb->right);
    free(arb);
}
