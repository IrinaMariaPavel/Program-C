#include"pas6.h"

void print6(heap *h,FILE *f)
{
    fprintf(f,"%s %.2f\n",h->vec[0].c.nume,h->vec[0].c.experienta);//valoarea maxima se afla pe prima pozitie in heap
    fprintf(f,"%s %.2f\n",h->vec[2].c.nume,h->vec[2].c.experienta);//[2*i+2] vecin drept
    fprintf(f,"%s %.2f\n",h->vec[1].c.nume,h->vec[1].c.experienta);//[2*i+1] vecin stang
}