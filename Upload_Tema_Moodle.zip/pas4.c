#include"pas4.h"

heap * createh (){  //creaza heap
    heap * h = (heap *) malloc (sizeof(heap)); 
    if (h == NULL) { 
        printf("EROARE"); 
        return NULL;}
        h->size = 0;  
        h->capacity = 8; 
        h->vec = (participant*) malloc(sizeof(participant)*h->capacity); 
        if (h->vec == NULL) { printf("EROARE"); return NULL;}; 
        return h; 
    }
void deepCopy(participant *x,participant *y) //copiere variabila participant
{
    strcpy(x->c.nume,y->c.nume);
    x->c.varsta=y->c.varsta;
    x->c.experienta=y->c.experienta;
    x->c.statut=y->c.statut;
    strcpy(x->traseu,y->traseu);
    int i;
    for(i=0;i<10;i++) x->v[i]=y->v[i];
    x->nrt=y->nrt;
}
heap * inserth (heap *h, participant x){  //inserare in heap a participantului
    int i; 
    i=h->size;   
    h->size++;  
    while ( i > 0 &&  x.c.experienta > h->vec[(i-1)/2].c.experienta){ 
        deepCopy(&h->vec[i] , &h->vec[(i-1)/2]); 
        i=(i-1)/2; 
    }
        deepCopy(&h->vec[i] , &x); 
    return h;
 } 
 candidat* extrage(arbore **arb) {
    if (arb == NULL || *arb == NULL) {
        return NULL;
    }
    arbore *parent = NULL;
    arbore *current = *arb;
    while (current->right != NULL) {
        parent = current;
        current = current->right;
    }
    candidat *t = (candidat *)malloc(sizeof(candidat));
    if (t == NULL) {
        printf("Eroare la alocarea memoriei pentru candidat.\n");
        return NULL;
    }
    *t = current->val;
    if (parent != NULL) {
        parent->right = current->left;
    } else {
       
        *arb = current->left;
    }

    free(current); free(parent); free(t);
    return t;
}
 heap* citireTraseu(heap *h, FILE *f,arbore **BTS_ca,arbore **BTS_l)//atribuirea traseelor
 {
    int k=0,i,j;
    if (f == NULL) {
        printf("Eroare!\n");
        return NULL;
    }
    char l[265];
    

    while (fgets(l, sizeof(l), f))//citeste fiecare traseu
{
    i=0;
    k++;//contorizeaza ordinul candidatullui
    participant p;
    while(l[i]!=':'){
    p.traseu[i]=l[i]; i++;
    }
    i=i+2;j=0;

     char* nr = strtok(l+i, " ");
        while (nr && j < 10) {
            p.v[j++] = atoi(nr);
            nr = strtok(NULL, " ");
        }
        p.nrt=j;
    candidat* temp;

if (k % 2)
    temp= extrage(BTS_l);//ordin impar extrage lorzi
else
    temp= extrage(BTS_ca);//ordin par extrage cavaler sau aventurier

if (temp != NULL) {
    p.c = *temp; 
    free(temp);
    h=inserth(h,p);
    free(temp); free(nr);
}
}
 return h;
    fclose(f);
 
}
 void deleteh (heap**h){ //stergere heap
    if (*h==NULL) return; 
    free((*h)->vec); 
     free(*h ); *h=NULL; 
    }

void printHeap(heap *h,FILE *f){ //afisare
    int i; 
    for (i=0; i<h->size; i++) 
    fprintf(f,"%s - %s (%.2f)\n",h->vec[i].traseu,h->vec[i].c.nume,h->vec[i].c.experienta);
    fclose(f);
}