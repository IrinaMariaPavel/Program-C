#ifndef STRUCTURI_H
#define STRUCTURI_H

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

typedef enum {
    LORD,
    CAVALER,
    AVENTURIER
}statutSocial;
typedef struct {
    char nume[40];
    int varsta;
    float experienta;
    statutSocial statut;
}candidat;

typedef struct elem{
    candidat val;
    struct elem *next;
}nod;


typedef struct { 
    nod *front, *rear; 
 } coada;

typedef struct arbore{
    candidat val;
    struct arbore *left, *right;
}arbore;

typedef struct {
    candidat c;
    char traseu[3];
    int v[10],nrt;//nrt=numar de paduri
}participant;
typedef struct { 
    participant *vec;                  
    int size, capacity;     
    } heap;

typedef struct vecini{ 
    int nr; 
    struct vecini* next; 
} vecini;
typedef struct{ 
    int V, E; //numar de muchii si varfuri
    vecini ** a; 
} traseu;

#endif