#include"structuri.h"

heap* citireTraseu(heap *h, FILE *f,arbore **BTS_ca,arbore **BTS_l);
void printHeap(heap *h,FILE *f);
void deleteh (heap**h);
candidat *extrage(arbore **arb);
heap* inserth (heap *h, participant x);
void deepCopy(participant *x,participant *y);
heap * createh ();