#include "structuri.h"

 coada* creare();
 void adauga(coada *q, candidat v);
 coada* citesteFisier();
 void afisare(coada *q, FILE *f);
 statutSocial returnStatut(char *p);
 char* schimba(statutSocial p);
 int isEmpty(coada *q);
 void eliminaCoada(coada* q);