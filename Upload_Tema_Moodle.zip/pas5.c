#include"pas5.h"

heap* adaugaEXP(heap *h) //adauga experiemta dobandita
{
    int i,j;
    for(i=0;i<h->size;i++)
    {
        for(j=0;j<h->vec[i].nrt;j++)
        h->vec[i].c.experienta+=h->vec[i].v[j];
    }
    return h;
}
heap * rearanjare(heap *h,heap *g)//pastreaza proprietatea heap
{
    int i;
    for(i=0;i<h->size;i++)
    {
        g=inserth(g,h->vec[i]);//functia din pasul anterior
    }
    g->capacity=h->capacity;
    return g;

}