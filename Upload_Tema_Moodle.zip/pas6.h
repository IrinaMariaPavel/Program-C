#include"structuri.h"

void print6(heap *h,FILE *f);
