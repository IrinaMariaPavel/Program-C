#include"structuri.h"
#include"pas4.h"

heap* adaugaEXP(heap *h);
heap * rearanjare(heap *h,heap *g);