# tema-pa-ab-2025



## Getting started

To make it easy for you to get started with GitLab, here's a list of recommended next steps.

Already a pro? Just edit this README.md and make it your own. Want to make it easy? [Use the template at the bottom](#editing-this-readme)!

## Add your files

- [ ] [Create](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#create-a-file) or [upload](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#upload-a-file) files
- [ ] [Add files using the command line](https://docs.gitlab.com/topics/git/add_files/#add-files-to-a-git-repository) or push an existing Git repository with the following command:

```
cd existing_repo
git remote add origin https://gitlab.com/bogdangheorghe98/tema-pa-ab-2025.git
git branch -M main
git push -uf origin main
```

## Integrate with your tools

- [ ] [Set up project integrations](https://gitlab.com/bogdangheorghe98/tema-pa-ab-2025/-/settings/integrations)

## Collaborate with your team

- [ ] [Invite team members and collaborators](https://docs.gitlab.com/ee/user/project/members/)
- [ ] [Create a new merge request](https://docs.gitlab.com/ee/user/project/merge_requests/creating_merge_requests.html)
- [ ] [Automatically close issues from merge requests](https://docs.gitlab.com/ee/user/project/issues/managing_issues.html#closing-issues-automatically)
- [ ] [Enable merge request approvals](https://docs.gitlab.com/ee/user/project/merge_requests/approvals/)
- [ ] [Set auto-merge](https://docs.gitlab.com/user/project/merge_requests/auto_merge/)

## Test and Deploy

Use the built-in continuous integration in GitLab.

- [ ] [Get started with GitLab CI/CD](https://docs.gitlab.com/ee/ci/quick_start/)
- [ ] [Analyze your code for known vulnerabilities with Static Application Security Testing (SAST)](https://docs.gitlab.com/ee/user/application_security/sast/)
- [ ] [Deploy to Kubernetes, Amazon EC2, or Amazon ECS using Auto Deploy](https://docs.gitlab.com/ee/topics/autodevops/requirements.html)
- [ ] [Use pull-based deployments for improved Kubernetes management](https://docs.gitlab.com/ee/user/clusters/agent/)
- [ ] [Set up protected environments](https://docs.gitlab.com/ee/ci/environments/protected_environments.html)

***

# Editing this README

When you're ready to make this README your own, just edit this file and use the handy template below (or feel free to structure it however you want - this is just a starting point!). Thanks to [makeareadme.com](https://www.makeareadme.com/) for this template.

## Suggestions for a good README

Every project is different, so consider which of these sections apply to yours. The sections used in the template are suggestions for most open source projects. Also keep in mind that while a README can be too long and detailed, too long is better than too short. If you think your README is too long, consider utilizing another form of documentation rather than cutting out information.

## Name
Tema pa Pavel Irina Maria 313 AB

## Description
Proiectul contine 8 biblioteci, cate una pentru fiecare pas al cerintei si una pentru structurile folosite. 
Această aplicație în C are că scop procesarea și organizarea unui set de candidați în funcție de statutul social, experiență și trasee parcurse, folosind structuri de date avansate precum cozi, arbori binari de căutare (BST), heap-uri și grafuri. Procesul este împărțit în pași logici care implică citirea datelor, clasificarea, organizarea și afișarea acestora în diverse formate, cu accent pe manipularea eficientă a memoriei și păstrarea proprietăților structurale ale fiecărui tip de date.
 Primul pas presupune citirea linie cu linie a datelor dintr-un fișier de intrare și transformarea acestor date în variabile de tip candidat. Fiecare candidat este inițializat pe baza datelor primite și este introdus într-o coadă, structură aleasă pentru ordinea strictă de procesare a candidaților. Coada este ulterior afișată într-un fișier de ieșire.Acest pas conține și funcția de trasformare din char în variabila statutSocial de tip enum , dar și inversa. Am adăugat la acest pas funcția de ștergere a structurii coade și eliberarea memoriei.
 Pasul 2 împarte valorile din coada în doi arbori binari BTS_l pentru lorzi , BTS_ca pentru cavaleri și aventuriari.Conține funcția de afișare prin postorder în cele doua fișiere de ieșire , dar și cea de ștergere a arborelui. Este important de menționat că, în funcția main, după finalizarea acestui pas, se apelează explicit funcția de distrugere a cozii, deoarece toate datele relevante au fost deja transferate în arbori.
 Pasul 3 citește contestațiile linie cu linie, salvează contestația în variabile candidat la fel că în pas1 și o elimina.Ștergerea candidatului contestat păstrând proprietățile arborelui se face astfel:comparam experiență până găsim candidatul potrivit, daca nu avem nod în stangă îl înlocuim cu cel din dreapta, daca nu avem nod în dreapta îl înlocuim cu cel din stangă,altfel găsim minimul să înlocuim nodul( funcția minim returnează minimul ce se afla în dreapta în heap). Această operațiune asigură corectitudinea și echilibrul arborelui după eliminarea unui nod.
 Pasul 4 citește traseele linie cu linie din fișier și contorizează numărul traseului, dar și numărul de păduri atribuite fiecărui candidat. Ordinul impar al contorului extrage lorzi din arborele BTS_l, iar ordinul par un caveler sau aventurier din BTS_ca în erdinea în care apar.Datele citite și extrase sunt stocate în structura de tip participant prin funcția de inserare în heap. Heap-ul permite gestionarea eficientă a priorității participanților în funcție de experiență. Am adăugat funcția deepCopy care crează o copie profunda a variabilei de tip participant, cât și funcțiile de creare, ștergere și afișare ale heap-ului .
 Pasul 5 în urma parcurgerii traseelor, fiecare participant acumulează experiență, care este adăugată la valoarea să existentă. După această modificare, heap-ul trebuie rearanjat pentru a păstra proprietatea specifică (nodul de top fiind cel cu experiența maximă).. Pentru afișare am folosit funcția de la pasul anterior. 
Pasul 6 este destinat identificării celor mai valoroși participanți din heap. Deoarece heap-ul păstrează la vârf elementul cu experiența maximă, extragerea acestuia se face direct de pe poziția 0 din vectorul de heap. De asemenea, se extrag și vecinii din stânga și din dreapta ai acestuia, care se află pe pozițiile [2*i+1] și [2*i+2].Astfel, se pot afișa rapid primii trei candidați cu experiența cea mai mare. 
Ultimul pas implementează un graf orientat, ale cărui muchii sunt citite din fișier și stocate folosind liste de adiacență. Fiecare nod este reprezentat de o structură traseu, iar legăturile sunt memorate pentru a permite parcurgerea ulterioară.Pentru a identifica drumurile posibile prin pădure, se pornește de la nodurile cu grad de intrare zero (start[i] = 0) și se aplică o funcție recursivă DFS. Dacă nodul curent nu mai are vecini, înseamnă că am ajuns la o frunză și putem afișa întregul traseu parcurs până la acel punct. Variabila ind este folosită pentru a menține numărul traseului actual.Pasul include și o funcție de afișare a grafului, utilă pentru verificare vizuală, precum și o funcție de eliberare completă a memoriei alocate structurii graf. 
Proiectul a oferit o bună ocazie de a implementa și înțelege interacțiunea dintre diferite structuri de date fundamentale. Fiecare pas a fost gândit pentru a reflecta un proces real de selecție și organizare, utilizând metode eficiente și recursive. Deși au fost identificate unele scurgeri de memorie în etapa de gestionare a grafurilor, aplicația funcționează corect în ansamblu. Se pot aduce îmbunătățiri ulterioare prin analiză statică a memoriei și optimizări structurale. 
Scurgeri de memorie au fost detectate în pasul 7, în special la liniile 9 și 16 din fișierul pas7.c. Deși aceste linii conțin alocări de memorie aparent redundante, eliminarea lor face că programul să nu mai funcționeze corect. Această problemă necesită o analiză atentă a ciclului de viață al fiecărei alocări pentru a identifica unde exact se pierde referința către memoria alocată.


## Badges
On some READMEs, you may see small images that convey metadata, such as whether or not all the tests are passing for the project. You can use Shields to add some to your README. Many services also have instructions for adding a badge.

## Visuals
Depending on what you are making, it can be a good idea to include screenshots or even a video (you'll frequently see GIFs rather than actual videos). Tools like ttygif can help, but check out Asciinema for a more sophisticated method.

## Installation
Within a particular ecosystem, there may be a common way of installing things, such as using Yarn, NuGet, or Homebrew. However, consider the possibility that whoever is reading your README is a novice and would like more guidance. Listing specific steps helps remove ambiguity and gets people to using your project as quickly as possible. If it only runs in a specific context like a particular programming language version or operating system or has dependencies that have to be installed manually, also add a Requirements subsection.

## Usage
Use examples liberally, and show the expected output if you can. It's helpful to have inline the smallest example of usage that you can demonstrate, while providing links to more sophisticated examples if they are too long to reasonably include in the README.

## Support
Tell people where they can go to for help. It can be any combination of an issue tracker, a chat room, an email address, etc.

## Roadmap
If you have ideas for releases in the future, it is a good idea to list them in the README.

## Contributing
State if you are open to contributions and what your requirements are for accepting them.

For people who want to make changes to your project, it's helpful to have some documentation on how to get started. Perhaps there is a script that they should run or some environment variables that they need to set. Make these steps explicit. These instructions could also be useful to your future self.

You can also document commands to lint the code or run tests. These steps help to ensure high code quality and reduce the likelihood that the changes inadvertently break something. Having instructions for running tests is especially helpful if it requires external setup, such as starting a Selenium server for testing in a browser.

## Authors and acknowledgment
Show your appreciation to those who have contributed to the project.

## License
For open source projects, say how it is licensed.

## Project status
If you have run out of energy or time for your project, put a note at the top of the README saying that development has slowed down or stopped completely. Someone may choose to fork your project or volunteer to step in as a maintainer or owner, allowing your project to keep going. You can also make an explicit request for maintainers.
