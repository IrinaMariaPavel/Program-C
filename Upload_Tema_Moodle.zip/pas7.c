#include"pas7.h"

traseu* cirireDrum(FILE *f,int start[])//citire si fomare graf
{
    int x,y,i;
    traseu *tr=(traseu*)malloc(sizeof(traseu));
    if(tr==NULL) return NULL;
    tr->V=11;
    tr->a=(vecini**)malloc(tr->V* sizeof(vecini*));
    if (f == NULL) {
        printf("Eroare!\n");
        return NULL;
    }
    char l[265];
    for(i=0;i<11;i++){
        tr->a[i] = (vecini*)malloc(sizeof(vecini));
    tr->a[i]->nr = i;
    tr->a[i]->next = NULL;
    }
    while (fgets(l, sizeof(l), f))
    {
        char* nr = strtok(l, " ");
        x= atoi(nr);
        nr = strtok(NULL, " ");
        y=atoi(nr);
        vecini *q=(vecini*)malloc(sizeof(vecini));
        q->nr=y;
        q->next=NULL;
        // Inserare ordonată în lista tr->a[x]
    vecini *p = tr->a[x];
    vecini *prev = NULL;

    while (p != NULL && p->nr < y) {
        prev = p;
        p = p->next;
    }

    if (prev == NULL) {
        // inserare la început
        q->next = tr->a[x];
        tr->a[x] = q;
    } else {
        // inserare între prev și p
        prev->next = q;
        q->next = p;
    }

    start[y]++;
    }
    fclose(f);
    return tr;
   
}
void Drum(traseu *tr, FILE *f, int nodStart,int *ind) {
    int *vizitat = calloc(tr->V, sizeof(int));
    int *drum = malloc(tr->V * sizeof(int)); 
    int lungime = 0;
    DFS(tr, nodStart, vizitat, drum, lungime, f,ind);
    free(vizitat);
    free(drum);
}
void printGraph(traseu *g,FILE *f){ //afisarea grafului folosita pentru verificare
    int i, j; 
    for (i=0; i<g->V; i++) { 
        vecini*p = g->a[i]; 
        while (p!=NULL)    {
             fprintf( f,"%d ", p->nr); 
             p = p->next; } 
             fprintf(f,"\n"); } }
void DFS(traseu *tr, int curent, int *vizitat, int *drum, int lungime, FILE *f,int *ind) {
     vizitat[curent] = 1;
    drum[lungime++] = curent;

    // Dacă nodul curent NU are vecini, e o frunză => afisam drumul complet
    if (tr->a[curent]->next == NULL) {
        fprintf(f, "T%d: ", (*ind)++);
        for (int i = 0; i < lungime; i++)
            fprintf(f, "%d ", drum[i]);
        fprintf(f, "\n");
    } else {
        vecini *v = tr->a[curent];
        while (v != NULL) {
            if (!vizitat[v->nr]) {
                DFS(tr, v->nr, vizitat, drum, lungime, f, ind);
            }
            v = v->next;
        }
    }

    vizitat[curent] = 0; 
}
void freeTraseu(traseu *tr) {//stergere graf
    for (int i = 0; i < tr->V; i++) {
        vecini *p = tr->a[i];
        while (p != NULL) {
            vecini *tmp = p;
            p = p->next;
            free(tmp);
        }
    }
    free(tr->a);
    free(tr);
}