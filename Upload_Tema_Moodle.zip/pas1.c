#include "pas1.h"

char* schimba(statutSocial p) //schimba tipul enum in char pentru folosirea in comparatii
{

    switch(p)
    {
        case LORD: return "LORD";
        case CAVALER: return "CAVALER";
        default: return "AVENTURIER";

    }
}
coada* creare()//functia de creare a unei cozi
{
    coada *q;
    q = (coada *)malloc(sizeof(coada));
    if (q == NULL)
    {
        printf("EROARE\n");
        return NULL;
    }
    q->front = NULL;
    q->rear = NULL;
    return q;
    
}

void adauga(coada *q, candidat v) //agauga fiecare candidat in coada
{
    nod* newNode = (nod*)malloc(sizeof(nod));
    if (newNode == NULL)
    {
        printf("EROARE\n");
        return;
    }
    newNode->val = v;
    newNode->next=NULL;
    if (q->rear == NULL)
        q->rear = newNode;
    else{
        (q->rear)->next = newNode;
        (q->rear) = newNode; }
    if (q->front == NULL)
        q->front = q->rear;
    
}
statutSocial returnStatut(char *p) //schimba din char in enum (proces invers functiei schimba)
{

    if (strcmp(p, "LORD") == 0)
        return LORD;
    else if (strcmp(p, "CAVALER") == 0)
        return CAVALER;
    else if (strcmp(p, "AVENTURIER") == 0)
        return AVENTURIER;

}

coada* citesteFisier() // citeste din fisier si creaza coada
{
    coada* q;
	q = creare();
    FILE* f = fopen("Pas_1/candidati.csv", "r");
    if (f == NULL) {
        printf("Eroare!\n");
        return NULL;
    }
    char l[265];
    fgets(l, sizeof(l), f);//citeste prima linie

    while (fgets(l, sizeof(l), f))//citeste fiecare linie
{
    candidat candidat;
    char p[11];
    int i=0;
    // STATUT
    while(l[i]!=' ')
    {
        p[i] = toupper(l[i]);
        i++;

    }
    p[i]='\0';
    candidat.statut=returnStatut(p);
    int j=0,ok=0;
    i++;
    //NUME
    while(l[i]!=';')
    {
        if(l[i]==' ')
        {candidat.nume[j]='-'; ok=0;}
    else if(ok==0)
    {
        candidat.nume[j]=toupper(l[i]);
        ok=1;
    }else
        candidat.nume[j]=tolower(l[i]);
    i++;
    j++;
    }
    candidat.nume[j]='\0';
    //EXPERIENTA
    i++; j=0;
    while(l[i]!=';')
    {
        p[j]=l[i];
        j++; i++;
    }
    p[j]='\0';
    candidat.experienta=atof(p);
    //VARSTA
    i++; j=0;
    while(l[i])
    {
        p[j]=l[i];
        j++; i++;
    }
    p[j]='\0';
    candidat.varsta=atoi(p);
    adauga(q, candidat);

}
fclose(f);
return q;
}
void afisare(coada *q, FILE *f)
{

    fprintf(f,"Nume Experienta Varsta Statut_social\n");
    nod *p;
    p= q->front;
    while (p != NULL) {
        fprintf(f,"%s %.2f %d %s\n",
               p->val.nume,
               p->val.experienta,
               p->val.varsta,
               schimba(p->val.statut)
            );
        p = p->next;
    }
    fclose(f);
   
}
int isEmpty(coada *q){ 
    return (q->front == NULL); 
 } 
void eliminaCoada(coada* q)
{ nod* aux;
    while (!isEmpty(q))
    { 
        aux=q->front; 
        q->front=q->front->next; 
        free(aux); 
    } 
        free(q); 
}