#include"structuri.h"
#include"pas1.h"

arbore * minim(arbore* arb);
arbore* elimina(arbore *arb,candidat c);
void citesteContestatii(arbore *arb);