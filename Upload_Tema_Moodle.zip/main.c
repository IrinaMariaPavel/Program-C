#include"structuri.h"
#include"pas1.h"
#include"pas2.h"
#include"pas3.h"
#include"pas4.h"
#include"pas5.h"
#include"pas6.h"
#include"pas7.h"

int main()
{
	/// PAS 1
	// Read from "Pas_1/candidati.csv"
	coada* q;
    q=citesteFisier();
	// Write to "Pas_1/test_1.csv"
	FILE *f = fopen("Pas_1/test_1.csv", "w");
	afisare(q,f);
	// PAS 2
	arbore *BTS_l = NULL, *BTS_ca = NULL;
    selectie(q, &BTS_l, &BTS_ca);
    eliminaCoada(q);
	//afisare lorzi
	f = fopen("Pas_2/test_2_lorzi.csv", "w");
    if (f) {
	    fprintf(f,"Nume Experienta Varsta Statut_social\n");
        postorder(BTS_l, f);
        fclose(f);
    }
	//afisare cavaleri si aventurieri
    f = fopen("Pas_2/test_2_cavaleri_aventurieri.csv", "w");
    if (f) {
	    fprintf(f,"Nume Experienta Varsta Statut_social\n");
        postorder(BTS_ca, f);
        fclose(f);
    }
    // PAS 3
	citesteContestatii(BTS_l);
	f = fopen("Pas_3/test_3_lorzi.csv", "w");
    if (f) {
	    fprintf(f,"Nume Experienta Varsta Statut_social\n");
        postorder(BTS_l, f);
        fclose(f);
    }
    // PAS 4
	heap *h;
	h=createh();
	f=fopen("Pas_4/trasee.csv","r");
	h=citireTraseu(h,f,&BTS_ca,&BTS_l);
	deleteARB(BTS_l);
	BTS_l=NULL;
	deleteARB(BTS_ca);
	BTS_ca=NULL;
	f=fopen("Pas_4/test_4.csv","w");
	fprintf(f,"Nume_Traseu - Nume_Participant (Experienta_participant)\n");
	printHeap(h,f);
	// PAS 5
	h=adaugaEXP(h);
	heap *g;
	g=createh();
	g=rearanjare(h,g);
	deleteh(&h);
	f=fopen("Pas_5/test_5.csv","w");
	fprintf(f,"Nume_Traseu - Nume_Participant (Experienta_participant)\n");
	printHeap(g,f);
	// PAS 6
	f=fopen("Pas_6/test_6.csv","w");
	fprintf(f,"Nume Experienta_totala\n");
	print6(g,f);
	fclose(f);
	deleteh(&g);
	// PAS 7
	f=fopen("Pas_7/drumuri.csv","r");
	traseu *tr;
	int start[11];//vector de frecventa
	int i;
	for(i=0;i<11;i++) start[i]=0;//initializare
	tr=cirireDrum(f,start);
	f=fopen("Pas_7/test_7.csv","w");
	int ind=1;
	for(i=0;i<tr->V;i++)
	if(start[i]==0)// încep dintr-un nod cu grad de intrare zero
	Drum(tr,f,i,&ind);
	fclose(f);
	freeTraseu(tr);
	return 0;
}